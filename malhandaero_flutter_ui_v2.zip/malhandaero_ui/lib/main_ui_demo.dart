import 'package:flutter/material.dart';

import 'ui/app.dart';

/// 와이어프레임 5차 화면 데모 실행용.
/// 기존 main.dart는 건드리지 않아요.
///   flutter run -t lib/main_ui_demo.dart
void main() {
  runApp(const MalhandaeroApp());
}
