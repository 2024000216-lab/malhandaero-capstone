/// 일정 하나.
class Schedule {
  const Schedule({
    required this.id,
    required this.title,
    required this.dateTime,
    this.place,
    this.repeatLabel,
  });

  final String id;

  /// 할 일 (예: 치과)
  final String title;

  /// 날짜 + 시간
  final DateTime dateTime;

  /// 장소. 말하지 않았으면 null
  final String? place;

  /// 반복 설명 (예: 매주 화요일마다). 반복이 없으면 null
  final String? repeatLabel;

  Schedule copyWith({
    String? title,
    DateTime? dateTime,
    String? place,
    String? repeatLabel,
  }) {
    return Schedule(
      id: id,
      title: title ?? this.title,
      dateTime: dateTime ?? this.dateTime,
      place: place ?? this.place,
      repeatLabel: repeatLabel ?? this.repeatLabel,
    );
  }
}
