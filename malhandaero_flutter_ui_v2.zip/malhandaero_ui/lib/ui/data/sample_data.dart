import '../models/schedule.dart';
import '../utils/clock.dart';
import '../utils/date_format.dart';

/// 와이어프레임과 같은 예시 데이터.
/// 날짜는 실행한 날을 기준으로 '오늘·내일·이번 금요일'에 맞춰 만들어져요.
/// TODO: Firebase 연결 후 저장된 일정으로 바꾸세요.
class DemoData {
  DemoData._();

  static const heardText = '내일 오후 2시에 치과 가고, 금요일에 정형외과';

  static int _seq = 0;
  static String _newId() =>
      'draft-${DateTime.now().microsecondsSinceEpoch}-${_seq++}';

  static DateTime _today() => dateOnly(appNow());

  static DateTime _at(DateTime day, int hour, [int minute = 0]) =>
      DateTime(day.year, day.month, day.day, hour, minute);

  /// 오늘 이후 가장 가까운 금요일 (오늘이 금요일이면 다음 주 금요일)
  static DateTime _nextFriday() {
    final today = _today();
    var days = (DateTime.friday - today.weekday) % 7;
    if (days == 0) days = 7;
    return today.add(Duration(days: days));
  }

  static List<Schedule> schedules() {
    final today = _today();
    final tomorrow = today.add(const Duration(days: 1));
    return [
      Schedule(
        id: 's1',
        title: '팀 회의',
        dateTime: _at(today, 15),
        place: '도서관',
      ),
      Schedule(
        id: 's2',
        title: '저녁 약속',
        dateTime: _at(today, 19, 30),
      ),
      Schedule(
        id: 's3',
        title: '물리치료',
        dateTime: _at(tomorrow, 10),
        repeatLabel: '매주 ${weekdayShort(tomorrow)}요일마다',
      ),
    ];
  }

  /// 음성 인식 결과 예시 (저장 전 확인용)
  static List<Schedule> drafts() {
    final tomorrow = _today().add(const Duration(days: 1));
    return [
      Schedule(id: _newId(), title: '치과', dateTime: _at(tomorrow, 14)),
      Schedule(id: _newId(), title: '정형외과', dateTime: _at(_nextFriday(), 9)),
    ];
  }
}
