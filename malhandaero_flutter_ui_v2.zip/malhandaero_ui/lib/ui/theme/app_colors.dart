import 'package:flutter/material.dart';

import '../state/app_state.dart';

/// 와이어프레임 5차 색상표.
class AppColors {
  AppColors._();

  static const blue = Color(0xFF2B4ACB); // 기본 주요 색
  static const blueColorBlind = Color(0xFF1F4FD1); // 색약 모드 주요 색
  static const blueSoft = Color(0xFFEEF1FB);
  static const blueTint = Color(0xFFE8ECFB);
  static const orangeTint = Color(0xFFFCEEDF);
  static const orangeDeep = Color(0xFF9A4A00);

  static const ink = Color(0xFF1A1A1A);
  static const inkStrong = Color(0xFF111111);
  static const textSub = Color(0xFF555555);
  static const textMuted = Color(0xFF6B6B6B);
  static const grayBg = Color(0xFFF2F1ED);
  static const line = Color(0xFFE3E1DC);
  static const border = Color(0xFFD6D4CE);
  static const borderSoft = Color(0xFFCFCBC3);

  /// 색약 모드 여부에 맞는 주요 색.
  static Color primaryOf(BuildContext context) =>
      AppStateScope.of(context).colorBlind ? blueColorBlind : blue;
}
