import 'package:flutter/material.dart';

import '../flows/voice_flow.dart';
import '../models/schedule.dart';
import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../utils/date_format.dart';
import '../widgets/common.dart';
import 'edit_time_sheet.dart';
import 'schedule_list_screen.dart';

/// 01 이렇게 저장할까요? — 일정별로 날짜·시간·장소·할 일 칸을 나눠 보여줘요.
class SaveConfirmScreen extends StatefulWidget {
  const SaveConfirmScreen({
    super.key,
    required this.heardText,
    required this.drafts,
  });

  final String heardText;
  final List<Schedule> drafts;

  @override
  State<SaveConfirmScreen> createState() => _SaveConfirmScreenState();
}

class _SaveConfirmScreenState extends State<SaveConfirmScreen> {
  late final List<Schedule> _drafts = List.of(widget.drafts);

  void _replace(int index, Schedule updated) {
    if (!mounted) return;
    setState(() => _drafts[index] = updated);
  }

  Future<void> _editDate(int index) async {
    final current = _drafts[index].dateTime;
    final picked = await showDatePicker(
      context: context,
      initialDate: current,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked == null) return;
    _replace(
      index,
      _drafts[index].copyWith(
        dateTime: DateTime(
          picked.year,
          picked.month,
          picked.day,
          current.hour,
          current.minute,
        ),
      ),
    );
  }

  Future<void> _editTime(int index) async {
    final picked = await showEditTimeSheet(
      context,
      title: _drafts[index].title,
      current: _drafts[index].dateTime,
    );
    if (picked == null) return;
    _replace(index, _drafts[index].copyWith(dateTime: picked));
  }

  Future<void> _editPlace(int index) async {
    final text = await showDialog<String>(
      context: context,
      builder: (_) => _TextEditDialog(
        title: '장소를 알려주세요',
        initial: _drafts[index].place ?? '',
      ),
    );
    if (text == null || text.isEmpty) return;
    _replace(index, _drafts[index].copyWith(place: text));
  }

  Future<void> _editTitle(int index) async {
    final text = await showDialog<String>(
      context: context,
      builder: (_) => _TextEditDialog(
        title: '할 일을 고쳐 주세요',
        initial: _drafts[index].title,
      ),
    );
    if (text == null || text.isEmpty) return;
    _replace(index, _drafts[index].copyWith(title: text));
  }

  void _save() {
    AppStateScope.read(context).addSchedules(_drafts);
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const ScheduleListScreen()),
      (route) => route.isFirst,
    );
    messenger.showSnackBar(
      SnackBar(content: Text('일정 ${_drafts.length}개를 저장했어요')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primary = AppColors.primaryOf(context);

    return Scaffold(
      appBar: appHeader(context, title: '이렇게 저장할까요?', leadingLabel: '취소'),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _HeardBox(text: widget.heardText),
          const SizedBox(height: 18),
          Text.rich(
            TextSpan(
              children: [
                const TextSpan(text: '일정 '),
                TextSpan(
                  text: '${_drafts.length}개',
                  style: TextStyle(color: primary),
                ),
                const TextSpan(text: ', 맞나요?'),
              ],
            ),
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
          ),
          for (var i = 0; i < _drafts.length; i++) ...[
            const SizedBox(height: 18),
            _DraftCard(
              number: i + 1,
              schedule: _drafts[i],
              onEditDate: () => _editDate(i),
              onEditTime: () => _editTime(i),
              onEditPlace: () => _editPlace(i),
              onEditTitle: () => _editTitle(i),
            ),
          ],
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: AppColors.line)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              BigButton(label: '네, 저장할게요', fontSize: 22, onPressed: _save),
              const SizedBox(height: 4),
              TextButton(
                onPressed: () => startVoiceFlow(context, replace: true),
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.ink,
                  minimumSize: const Size(48, 48),
                ),
                child: const Text(
                  '처음부터 다시 말하기',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeardBox extends StatelessWidget {
  const _HeardBox({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.grayBg,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '제가 들은 말',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Color(0xFF4A4A4A),
            ),
          ),
          const SizedBox(height: 4),
          Text('“$text”', style: const TextStyle(fontSize: 19, height: 1.5)),
        ],
      ),
    );
  }
}

class _DraftCard extends StatelessWidget {
  const _DraftCard({
    required this.number,
    required this.schedule,
    required this.onEditDate,
    required this.onEditTime,
    required this.onEditPlace,
    required this.onEditTitle,
  });

  final int number;
  final Schedule schedule;
  final VoidCallback onEditDate;
  final VoidCallback onEditTime;
  final VoidCallback onEditPlace;
  final VoidCallback onEditTitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.ink, width: 2.5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Container(
            color: AppColors.ink,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    '$number',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: AppColors.ink,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    schedule.title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          _FieldRow(
            icon: Icons.calendar_today_rounded,
            label: '날짜',
            value: formatDate(schedule.dateTime),
            onEdit: onEditDate,
            showTopLine: false,
          ),
          _FieldRow(
            icon: Icons.schedule_rounded,
            label: '시간',
            value: formatTime(schedule.dateTime),
            onEdit: onEditTime,
          ),
          _FieldRow(
            icon: Icons.place_outlined,
            label: '장소',
            value: schedule.place,
            emptyText: '없음',
            onEdit: onEditPlace,
          ),
          _FieldRow(
            icon: Icons.check_rounded,
            label: '할 일',
            value: schedule.title,
            onEdit: onEditTitle,
          ),
        ],
      ),
    );
  }
}

class _FieldRow extends StatelessWidget {
  const _FieldRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.onEdit,
    this.emptyText = '',
    this.showTopLine = true,
  });

  final IconData icon;
  final String label;
  final String? value;
  final String emptyText;
  final VoidCallback onEdit;
  final bool showTopLine;

  @override
  Widget build(BuildContext context) {
    final isEmpty = value == null || value!.isEmpty;
    final primary = AppColors.primaryOf(context);

    return Container(
      constraints: const BoxConstraints(minHeight: 76),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: showTopLine
            ? const Border(top: BorderSide(color: AppColors.line, width: 1.5))
            : null,
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
              color: AppColors.grayBg,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 24, color: AppColors.ink),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSub,
                  ),
                ),
                Text(
                  isEmpty ? emptyText : value!,
                  style: isEmpty
                      ? const TextStyle(fontSize: 20, color: AppColors.textMuted)
                      : const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: onEdit,
            style: OutlinedButton.styleFrom(
              foregroundColor: primary,
              side: BorderSide(color: primary, width: 2),
              minimumSize: const Size(72, 48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              isEmpty ? '넣기' : '고치기',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}

/// 글자 고치기 창. 컨트롤러를 스스로 정리하도록 StatefulWidget으로 만들었어요.
class _TextEditDialog extends StatefulWidget {
  const _TextEditDialog({required this.title, required this.initial});

  final String title;
  final String initial;

  @override
  State<_TextEditDialog> createState() => _TextEditDialogState();
}

class _TextEditDialogState extends State<_TextEditDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      title: Text(
        widget.title,
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
      ),
      content: TextField(
        controller: _controller,
        autofocus: true,
        style: const TextStyle(fontSize: 20),
        decoration: const InputDecoration(border: OutlineInputBorder()),
        onSubmitted: (v) => Navigator.of(context).pop(v.trim()),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('취소', style: TextStyle(fontSize: 18)),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(_controller.text.trim()),
          child: const Text('확인', style: TextStyle(fontSize: 18)),
        ),
      ],
    );
  }
}
