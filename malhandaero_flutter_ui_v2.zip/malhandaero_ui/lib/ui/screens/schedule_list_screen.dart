import 'package:flutter/material.dart';

import '../flows/voice_flow.dart';
import '../models/schedule.dart';
import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../utils/clock.dart';
import '../utils/date_format.dart';
import '../widgets/common.dart';
import '../widgets/dashed_border.dart';
import 'edit_time_sheet.dart';

/// 05 일정 관리.
/// 색약 모드가 켜져 있으면 상태를 색이 아닌 테두리 모양과 글자로 구분해요.
///   끝난 일정 = 점선 + '끝남' / 다음 일정 = 굵은 테두리 + '▶ 다음 일정'
class ScheduleListScreen extends StatelessWidget {
  const ScheduleListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final colorBlind = state.colorBlind;
    final now = appNow();
    final today = dateOnly(now);

    final items =
        state.schedules.where((s) => !s.dateTime.isBefore(today)).toList();

    String? nextId;
    for (final s in items) {
      if (s.dateTime.isAfter(now)) {
        nextId = s.id;
        break;
      }
    }

    final children = <Widget>[];
    DateTime? currentDay;
    for (final s in items) {
      final day = dateOnly(s.dateTime);
      if (currentDay == null || day != currentDay) {
        if (currentDay != null) children.add(const SizedBox(height: 6));
        children.add(_DayHeader(
          text: dayHeader(day, now),
          isToday: day == today,
          colorBlind: colorBlind,
        ));
        currentDay = day;
      }
      children
        ..add(const SizedBox(height: 10))
        ..add(_ScheduleCard(
          schedule: s,
          done: !s.dateTime.isAfter(now),
          next: s.id == nextId,
          colorBlind: colorBlind,
          onTap: () => _openActions(context, s),
        ));
    }

    return Scaffold(
      appBar: appHeader(
        context,
        title: '일정 관리',
        leadingLabel: '뒤로',
        leadingIcon: Icons.chevron_left_rounded,
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                '아직 일정이 없어요',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
              children: children,
            ),
      bottomNavigationBar: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            border: Border(
              top: BorderSide(
                color: colorBlind ? AppColors.inkStrong : AppColors.line,
                width: colorBlind ? 2 : 1,
              ),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
          child: BigButton(
            label: '눌러서 말하기',
            icon: Icons.mic_none_rounded,
            fontSize: 21,
            onPressed: () => startVoiceFlow(context),
          ),
        ),
      ),
    );
  }

  Future<void> _openActions(BuildContext context, Schedule s) async {
    final state = AppStateScope.read(context);
    final action = await showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                s.title,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Text(
                '${formatDate(s.dateTime)} ${formatTime(s.dateTime)}',
                style: const TextStyle(fontSize: 18, color: AppColors.textSub),
              ),
              const SizedBox(height: 20),
              BigButton(
                label: '시간 바꾸기',
                icon: Icons.schedule_rounded,
                onPressed: () => Navigator.of(ctx).pop('time'),
              ),
              const SizedBox(height: 12),
              BigButton(
                label: '이 일정 지우기',
                icon: Icons.close_rounded,
                filled: false,
                onPressed: () => Navigator.of(ctx).pop('delete'),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.ink,
                  minimumSize: const Size(48, 48),
                ),
                child: const Text('닫기', style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );

    if (!context.mounted || action == null) return;

    if (action == 'time') {
      final picked =
          await showEditTimeSheet(context, title: s.title, current: s.dateTime);
      if (picked != null) state.updateSchedule(s.copyWith(dateTime: picked));
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        title: Text(
          '‘${s.title}’ 일정을 지울까요?',
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('그대로 둘게요', style: TextStyle(fontSize: 18)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('지울게요', style: TextStyle(fontSize: 18)),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    state.removeSchedule(s.id);
    showTodoSnack(context, '‘${s.title}’ 일정을 지웠어요');
  }
}

class _DayHeader extends StatelessWidget {
  const _DayHeader({
    required this.text,
    required this.isToday,
    required this.colorBlind,
  });

  final String text;
  final bool isToday;
  final bool colorBlind;

  @override
  Widget build(BuildContext context) {
    if (!colorBlind) {
      return Text(
        text,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: Color(0xFF333333),
        ),
      );
    }
    // 색약 모드: 오늘 = 검정 띠, 다른 날 = 테두리 띠
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
      decoration: BoxDecoration(
        color: isToday ? AppColors.inkStrong : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: isToday ? null : Border.all(color: AppColors.inkStrong, width: 2),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w800,
          color: isToday ? Colors.white : AppColors.inkStrong,
        ),
      ),
    );
  }
}

class _ScheduleCard extends StatelessWidget {
  const _ScheduleCard({
    required this.schedule,
    required this.done,
    required this.next,
    required this.colorBlind,
    required this.onTap,
  });

  final Schedule schedule;
  final bool done;
  final bool next;
  final bool colorBlind;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final primary = AppColors.primaryOf(context);

    final BorderSide side;
    if (done) {
      side = colorBlind
          ? BorderSide.none // 점선은 DashedBorder가 그려요
          : const BorderSide(color: AppColors.border, width: 1.5);
    } else if (next) {
      side = BorderSide(color: primary, width: colorBlind ? 4 : 2.5);
    } else {
      side = BorderSide(
        color: colorBlind ? AppColors.inkStrong : AppColors.border,
        width: colorBlind ? 2 : 1.5,
      );
    }

    final textColor = done
        ? (colorBlind ? AppColors.textSub : AppColors.textMuted)
        : AppColors.inkStrong;

    Widget card = Material(
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: side,
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (next) ...[
                TextTag(text: '▶ 다음 일정', filled: true, color: primary),
                const SizedBox(height: 6),
              ],
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          formatTime(schedule.dateTime),
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: textColor,
                          ),
                        ),
                        Text(
                          schedule.title,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: textColor,
                          ),
                        ),
                        if (schedule.place != null)
                          Text(
                            schedule.place!,
                            style: TextStyle(fontSize: 16, color: textColor),
                          ),
                        if (schedule.repeatLabel != null)
                          Text(
                            schedule.repeatLabel!,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: textColor,
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (done)
                    const TextTag(text: '끝남', color: Color(0xFF444444)),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (done && colorBlind) {
      card = DashedBorder(color: AppColors.textMuted, radius: 16, child: card);
    }
    return card;
  }
}
