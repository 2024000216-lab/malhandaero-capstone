import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';
import '../widgets/dashed_border.dart';

/// 04 설정 — 색약 모드 켜짐/꺼짐 + 미리보기, 크게 보기, 미리 알림.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);

    return Scaffold(
      appBar: appHeader(
        context,
        title: '설정',
        leadingLabel: '뒤로',
        leadingIcon: Icons.chevron_left_rounded,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 32),
        children: [
          _ToggleTile(
            title: '색약 모드',
            description: '색 대신 모양과 글자로 보여줘요',
            value: state.colorBlind,
            onChanged: state.setColorBlind,
          ),
          const SizedBox(height: 14),
          const _ColorBlindPreview(),
          const SizedBox(height: 14),
          _ToggleTile(
            title: '크게 보기 모드',
            description: '핵심 기능만 크게 보여줘요',
            value: state.largeMode,
            onChanged: (v) {
              state.setLargeMode(v);
              // 크게 보기를 켜면 바로 큰 홈 화면으로 돌아가요.
              if (v) Navigator.of(context).popUntil((r) => r.isFirst);
            },
          ),
          const SizedBox(height: 14),
          _ReminderSelector(
            value: state.reminderMinutes,
            onChanged: state.setReminderMinutes,
          ),
        ],
      ),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  const _ToggleTile({
    required this.title,
    required this.description,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String description;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: value,
      child: Material(
        color: Colors.white,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: value ? AppColors.inkStrong : AppColors.borderSoft,
            width: value ? 3 : 1.5,
          ),
        ),
        child: InkWell(
          onTap: () => onChanged(!value),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Color(0xFF444444),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                OnOffPill(on: value),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ColorBlindPreview extends StatelessWidget {
  const _ColorBlindPreview();

  @override
  Widget build(BuildContext context) {
    const labelStyle = TextStyle(fontSize: 19, fontWeight: FontWeight.w800);
    const saveStyle = TextStyle(
      fontSize: 19,
      fontWeight: FontWeight.w800,
      color: Colors.white,
    );

    return ExcludeSemantics(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.grayBg,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '켜면 이렇게 보여요',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppColors.blueColorBlind,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.check_rounded, color: Colors.white),
                        SizedBox(width: 6),
                        Text('저장', style: saveStyle),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DashedBorder(
                    color: AppColors.inkStrong,
                    strokeWidth: 3,
                    radius: 12,
                    child: Container(
                      height: 56,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.close_rounded, color: AppColors.inkStrong),
                          SizedBox(width: 6),
                          Text('지우기', style: labelStyle),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReminderSelector extends StatelessWidget {
  const _ReminderSelector({required this.value, required this.onChanged});

  final int value;
  final ValueChanged<int> onChanged;

  static const _options = {10: '10분 전', 30: '30분 전', 60: '1시간 전'};

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderSoft, width: 1.5),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '미리 알림',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              for (final entry in _options.entries) ...[
                if (entry.key != _options.keys.first) const SizedBox(width: 8),
                Expanded(
                  child: _ReminderOption(
                    label: entry.value,
                    selected: entry.key == value,
                    onTap: () => onChanged(entry.key),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _ReminderOption extends StatelessWidget {
  const _ReminderOption({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      fontSize: 17,
      fontWeight: selected ? FontWeight.w800 : FontWeight.w700,
    );
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));

    return SizedBox(
      height: 56,
      child: selected
          ? FilledButton(
              onPressed: onTap,
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.inkStrong,
                foregroundColor: Colors.white,
                shape: shape,
                padding: EdgeInsets.zero,
              ),
              child: FittedBox(
                child: Row(
                  children: [
                    const Icon(Icons.check_rounded, size: 18),
                    Text(label, style: style),
                  ],
                ),
              ),
            )
          : OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.inkStrong,
                side: const BorderSide(color: AppColors.textMuted, width: 2),
                shape: shape,
                padding: EdgeInsets.zero,
              ),
              child: FittedBox(child: Text(label, style: style)),
            ),
    );
  }
}
