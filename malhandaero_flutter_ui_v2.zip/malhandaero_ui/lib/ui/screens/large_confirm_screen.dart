import 'package:flutter/material.dart';

import '../models/schedule.dart';
import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../utils/date_format.dart';
import '../widgets/common.dart';
import 'save_confirm_screen.dart';

/// 07 크게 보기 — 일정을 하나씩 확인해요. (맞아요 / 고칠래요)
class LargeConfirmScreen extends StatefulWidget {
  const LargeConfirmScreen({
    super.key,
    required this.heardText,
    required this.drafts,
  });

  final String heardText;
  final List<Schedule> drafts;

  @override
  State<LargeConfirmScreen> createState() => _LargeConfirmScreenState();
}

class _LargeConfirmScreenState extends State<LargeConfirmScreen> {
  int _index = 0;

  void _accept() {
    if (_index < widget.drafts.length - 1) {
      setState(() => _index++);
      return;
    }
    AppStateScope.read(context).addSchedules(widget.drafts);
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).popUntil((route) => route.isFirst);
    messenger.showSnackBar(
      SnackBar(content: Text('일정 ${widget.drafts.length}개를 저장했어요')),
    );
  }

  void _fix() {
    // 고칠 때는 칸별로 고칠 수 있는 확인 화면으로 넘어가요.
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => SaveConfirmScreen(
          heardText: widget.heardText,
          drafts: widget.drafts,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.drafts.length;
    final s = widget.drafts[_index];

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).maybePop(),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.ink,
                      minimumSize: const Size(48, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                    ),
                    child: const Text('취소', style: TextStyle(fontSize: 20)),
                  ),
                  const Spacer(),
                  for (var i = 0; i < total; i++) ...[
                    Container(
                      width: 28,
                      height: 8,
                      decoration: BoxDecoration(
                        color: i <= _index ? AppColors.ink : Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: AppColors.ink, width: 2),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    '${_index + 1} / $total',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                '이 일정이 맞나요?',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColors.ink, width: 3),
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _BigField(label: '할 일', value: s.title, size: 40, first: true),
                            _BigField(label: '날짜', value: formatDate(s.dateTime)),
                            _BigField(label: '시간', value: formatTime(s.dateTime)),
                            _BigField(
                              label: '장소',
                              value: s.place ?? '없음',
                              size: 24,
                              muted: s.place == null,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 52,
                        child: TextButton.icon(
                          // TODO: TTS 연결
                          onPressed: () =>
                              showTodoSnack(context, '읽어주기는 TTS 연결 후 동작해요'),
                          icon: const Icon(Icons.volume_up_rounded, size: 24),
                          label: const Text(
                            '소리로 읽어주기',
                            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
                          ),
                          style: TextButton.styleFrom(
                            backgroundColor: AppColors.grayBg,
                            foregroundColor: AppColors.ink,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: BigButton(
                      label: '고칠래요',
                      filled: false,
                      height: 96,
                      fontSize: 26,
                      onPressed: _fix,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: BigButton(
                      label: '맞아요',
                      height: 96,
                      fontSize: 26,
                      onPressed: _accept,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BigField extends StatelessWidget {
  const _BigField({
    required this.label,
    required this.value,
    this.size = 28,
    this.muted = false,
    this.first = false,
  });

  final String label;
  final String value;
  final double size;
  final bool muted;
  final bool first;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
      decoration: BoxDecoration(
        border: first
            ? null
            : const Border(top: BorderSide(color: AppColors.line, width: 2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 18, color: Color(0xFF4A4A4A)),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: size,
              fontWeight: muted ? FontWeight.w500 : FontWeight.w800,
              color: muted ? const Color(0xFF5A5A5A) : AppColors.ink,
            ),
          ),
        ],
      ),
    );
  }
}
