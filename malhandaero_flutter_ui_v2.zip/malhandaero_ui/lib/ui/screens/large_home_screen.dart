import 'package:flutter/material.dart';

import '../flows/voice_flow.dart';
import '../models/schedule.dart';
import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../utils/clock.dart';
import '../utils/date_format.dart';
import '../widgets/common.dart';
import 'schedule_list_screen.dart';

/// 06 크게 보기 — 홈. 다음 일정 하나만 크게 보여줘요.
class LargeHomeScreen extends StatelessWidget {
  const LargeHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final now = appNow();
    final todayCount =
        state.schedules.where((s) => isSameDay(s.dateTime, now)).length;

    Schedule? next;
    for (final s in state.schedules) {
      if (s.dateTime.isAfter(now)) {
        next = s;
        break;
      }
    }

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: (constraints.maxHeight - 52).clamp(0.0, double.infinity),
              ),
              child: IntrinsicHeight(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      formatDate(now),
                      style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 18),
                    _NextCard(schedule: next, now: now),
                    const Spacer(),
                    const SizedBox(height: 24),
                    BigButton(
                      label: '말로 일정 등록',
                      icon: Icons.mic_none_rounded,
                      height: 112,
                      fontSize: 28,
                      onPressed: () => startVoiceFlow(context),
                    ),
                    const SizedBox(height: 18),
                    BigButton(
                      label: '오늘 일정 모두 보기 ($todayCount개)',
                      filled: false,
                      height: 76,
                      fontSize: 24,
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => const ScheduleListScreen(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () =>
                          AppStateScope.read(context).setLargeMode(false),
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFF4A4A4A),
                        minimumSize: const Size(48, 48),
                      ),
                      child: const Text(
                        '보통 화면으로',
                        style: TextStyle(
                          fontSize: 19,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NextCard extends StatelessWidget {
  const _NextCard({required this.schedule, required this.now});

  final Schedule? schedule;
  final DateTime now;

  @override
  Widget build(BuildContext context) {
    final s = schedule;

    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.ink, width: 3),
        borderRadius: BorderRadius.circular(24),
      ),
      child: s == null
          ? const Text(
              '남은 일정이 없어요',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        '다음 일정',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF4A4A4A),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.ink,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        timeUntil(s.dateTime, now),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  formatTime(s.dateTime),
                  style: const TextStyle(
                    fontSize: 52,
                    fontWeight: FontWeight.w800,
                    height: 1.2,
                  ),
                ),
                Text(
                  s.title,
                  style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800),
                ),
                if (s.place != null)
                  Text(
                    s.place!,
                    style: const TextStyle(fontSize: 24, color: Color(0xFF4A4A4A)),
                  ),
                const SizedBox(height: 16),
                BigButton(
                  label: '소리로 읽어주기',
                  icon: Icons.volume_up_rounded,
                  filled: false,
                  height: 56,
                  fontSize: 20,
                  // TODO: flutter_tts 같은 TTS로 연결하세요.
                  onPressed: () => showTodoSnack(context, '읽어주기는 TTS 연결 후 동작해요'),
                ),
              ],
            ),
    );
  }
}
