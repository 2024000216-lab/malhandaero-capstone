import 'package:flutter/material.dart';

import '../models/schedule.dart';
import '../state/app_state.dart';
import '../theme/app_colors.dart';
import '../utils/clock.dart';
import '../utils/date_format.dart';
import 'schedule_list_screen.dart';
import 'settings_screen.dart';

/// 03 메뉴 — 일정 관리 진입 + 보기 설정 바로 켜기.
class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final now = appNow();
    final canClose = Navigator.of(context).canPop();

    final todayItems =
        state.schedules.where((s) => isSameDay(s.dateTime, now)).toList();
    Schedule? next;
    for (final s in state.schedules) {
      if (s.dateTime.isAfter(now)) {
        next = s;
        break;
      }
    }
    final scheduleSummary = next == null
        ? '오늘 ${todayItems.length}개 · 남은 일정이 없어요'
        : '오늘 ${todayItems.length}개 · 다음 ${formatTime(next.dateTime)} ${next.title}';

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 60,
        automaticallyImplyLeading: false,
        leadingWidth: 108,
        leading: canClose
            ? TextButton.icon(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded, size: 22),
                label: const Text('닫기', style: TextStyle(fontSize: 18)),
                style: TextButton.styleFrom(foregroundColor: AppColors.ink),
              )
            : null,
        centerTitle: true,
        title: const Text(
          '메뉴',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
        ),
        shape: const Border(bottom: BorderSide(color: AppColors.line)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          const _SectionLabel('무엇을 볼까요?'),
          const SizedBox(height: 14),
          _ModeTile(
            icon: Icons.calendar_today_rounded,
            iconBg: AppColors.blueTint,
            iconColor: AppColors.blue,
            title: '일정 관리',
            description: '보고, 고치고, 지워요',
            summary: scheduleSummary,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ScheduleListScreen()),
            ),
          ),
          const SizedBox(height: 24),
          const _SectionLabel('보기 설정'),
          const SizedBox(height: 14),
          Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.border, width: 1.5),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                _QuickToggle(
                  title: '크게 보기',
                  description: '핵심 기능만 크게',
                  value: state.largeMode,
                  onChanged: state.setLargeMode,
                ),
                const Divider(height: 1, color: AppColors.line),
                _QuickToggle(
                  title: '색약 모드',
                  description: '색 대신 모양과 글자로 구분',
                  value: state.colorBlind,
                  onChanged: state.setColorBlind,
                ),
                const Divider(height: 1, color: AppColors.line),
                Material(
                  color: Colors.white,
                  child: InkWell(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const SettingsScreen(),
                      ),
                    ),
                    child: const SizedBox(
                      height: 64,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 18),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '설정 전체 보기',
                                style: TextStyle(
                                  fontSize: 19,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            Icon(
                              Icons.chevron_right_rounded,
                              color: Color(0xFF777777),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w700,
        color: Color(0xFF4A4A4A),
      ),
    );
  }
}

class _ModeTile extends StatelessWidget {
  const _ModeTile({
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.title,
    required this.description,
    required this.summary,
    required this.onTap,
  });

  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final String title;
  final String description;
  final String summary;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.ink, width: 2),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: iconBg,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(icon, size: 30, color: iconColor),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          description,
                          style: const TextStyle(
                            fontSize: 16,
                            color: AppColors.textSub,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, size: 30),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.grayBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(summary, style: const TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickToggle extends StatelessWidget {
  const _QuickToggle({
    required this.title,
    required this.description,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String description;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: value,
      child: Material(
        color: Colors.white,
        child: InkWell(
          onTap: () => onChanged(!value),
          child: Container(
            constraints: const BoxConstraints(minHeight: 64),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 14,
                          color: AppColors.textSub,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: value ? AppColors.ink : Colors.white,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: AppColors.ink, width: 2),
                  ),
                  child: Text(
                    value ? '켜짐' : '꺼짐',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: value ? Colors.white : AppColors.ink,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
