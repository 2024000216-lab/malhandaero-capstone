import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../utils/date_format.dart';
import '../widgets/common.dart';

/// 02 항목 바꾸기 — 시간 고르기 바텀시트.
/// 고른 시각(날짜는 그대로)을 돌려줘요. 닫으면 null.
Future<DateTime?> showEditTimeSheet(
  BuildContext context, {
  required String title,
  required DateTime current,
}) {
  return showModalBottomSheet<DateTime>(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => _EditTimeSheet(title: title, current: current),
  );
}

class _EditTimeSheet extends StatelessWidget {
  const _EditTimeSheet({required this.title, required this.current});

  final String title;
  final DateTime current;

  static const _hours = [9, 12, 15, 18];

  DateTime _withHour(int hour, [int minute = 0]) =>
      DateTime(current.year, current.month, current.day, hour, minute);

  Future<void> _pickOther(BuildContext context) async {
    // TODO: '말로 하기' — 음성 인식으로 시간만 받아오도록 연결하세요.
    // 연결 전까지는 시간 선택 창으로 대신해요.
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(current),
    );
    if (picked == null || !context.mounted) return;
    Navigator.of(context).pop(_withHour(picked.hour, picked.minute));
  }

  @override
  Widget build(BuildContext context) {
    final primary = AppColors.primaryOf(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textSub,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        '몇 시로 바꿀까요?',
                        style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: TextButton.styleFrom(
                    backgroundColor: AppColors.grayBg,
                    foregroundColor: AppColors.ink,
                    minimumSize: const Size(64, 48),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    '닫기',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 2.1,
              children: [
                for (final h in _hours)
                  _TimeOption(
                    label: formatTime(_withHour(h)),
                    isCurrent: current.hour == h && current.minute == 0,
                    primary: primary,
                    onTap: () => Navigator.of(context).pop(_withHour(h)),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            BigButton(
              label: '다른 시간은 말로 하기',
              icon: Icons.mic_none_rounded,
              height: 76,
              fontSize: 22,
              onPressed: () => _pickOther(context),
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeOption extends StatelessWidget {
  const _TimeOption({
    required this.label,
    required this.isCurrent,
    required this.primary,
    required this.onTap,
  });

  final String label;
  final bool isCurrent;
  final Color primary;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        backgroundColor: isCurrent ? AppColors.blueSoft : Colors.white,
        foregroundColor: AppColors.ink,
        side: BorderSide(
          color: isCurrent ? primary : AppColors.textMuted,
          width: isCurrent ? 3 : 2,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: EdgeInsets.zero,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          if (isCurrent)
            Text(
              '지금 시간',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: primary,
              ),
            ),
        ],
      ),
    );
  }
}
