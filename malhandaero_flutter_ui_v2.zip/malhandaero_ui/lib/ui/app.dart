import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'data/sample_data.dart';
import 'screens/large_home_screen.dart';
import 'screens/menu_screen.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';

/// 와이어프레임 5차 화면 묶음의 시작점.
class MalhandaeroApp extends StatefulWidget {
  const MalhandaeroApp({super.key});

  @override
  State<MalhandaeroApp> createState() => _MalhandaeroAppState();
}

class _MalhandaeroAppState extends State<MalhandaeroApp> {
  // TODO: Firebase 연결 후 예시 데이터 대신 저장된 일정을 불러오세요.
  final AppState _state = AppState(initial: DemoData.schedules());

  @override
  void dispose() {
    _state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      state: _state,
      child: MaterialApp(
        title: '말한대로',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        locale: const Locale('ko', 'KR'),
        supportedLocales: const [Locale('ko', 'KR')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const _HomeSwitcher(),
      ),
    );
  }
}

/// 크게 보기 모드면 큰 홈, 아니면 메뉴를 첫 화면으로 보여줘요.
class _HomeSwitcher extends StatelessWidget {
  const _HomeSwitcher();

  @override
  Widget build(BuildContext context) {
    final large = AppStateScope.of(context).largeMode;
    return large ? const LargeHomeScreen() : const MenuScreen();
  }
}
