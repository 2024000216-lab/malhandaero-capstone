import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme/app_colors.dart';

/// 화면 상단 바. 왼쪽 글자 버튼(취소/뒤로/닫기) + 가운데 제목.
PreferredSizeWidget appHeader(
  BuildContext context, {
  required String title,
  String? leadingLabel,
  IconData? leadingIcon,
  VoidCallback? onLeading,
}) {
  final colorBlind = AppStateScope.of(context).colorBlind;

  Widget? leading;
  if (leadingLabel != null) {
    leading = TextButton(
      onPressed: onLeading ?? () => Navigator.of(context).maybePop(),
      style: TextButton.styleFrom(
        foregroundColor: AppColors.ink,
        minimumSize: const Size(48, 48),
        padding: const EdgeInsets.symmetric(horizontal: 12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (leadingIcon != null) Icon(leadingIcon, size: 22),
          Text(leadingLabel, style: const TextStyle(fontSize: 18)),
        ],
      ),
    );
  }

  return AppBar(
    toolbarHeight: 60,
    automaticallyImplyLeading: false,
    leadingWidth: 108,
    leading: leading,
    centerTitle: true,
    title: Text(
      title,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
      ),
    ),
    shape: Border(
      bottom: BorderSide(
        color: colorBlind ? AppColors.inkStrong : AppColors.line,
        width: colorBlind ? 2 : 1,
      ),
    ),
  );
}

/// 큰 버튼. filled=false 이면 테두리 버튼.
class BigButton extends StatelessWidget {
  const BigButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.height = 64,
    this.fontSize = 20,
    this.filled = true,
    this.color,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final double height;
  final double fontSize;
  final bool filled;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(16));
    final content = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[
          Icon(icon, size: fontSize + 6),
          const SizedBox(width: 10),
        ],
        Flexible(
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );

    return SizedBox(
      width: double.infinity,
      height: height,
      child: filled
          ? FilledButton(
              onPressed: onPressed,
              style: FilledButton.styleFrom(
                backgroundColor: color ?? AppColors.primaryOf(context),
                foregroundColor: Colors.white,
                shape: shape,
              ),
              child: content,
            )
          : OutlinedButton(
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                foregroundColor: color ?? AppColors.ink,
                side: BorderSide(color: color ?? AppColors.ink, width: 2.5),
                shape: shape,
              ),
              child: content,
            ),
    );
  }
}

/// 켜짐/꺼짐 표시. 색이 아니라 모양(꽉 참/테두리)과 글자로 구분해요.
class OnOffPill extends StatelessWidget {
  const OnOffPill({super.key, required this.on});

  final bool on;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      height: 52,
      decoration: BoxDecoration(
        color: on ? AppColors.inkStrong : Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: on ? null : Border.all(color: AppColors.textMuted, width: 2),
      ),
      alignment: Alignment.center,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (on) const Icon(Icons.check_rounded, size: 20, color: Colors.white),
          Text(
            on ? '켜짐' : '꺼짐',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: on ? Colors.white : const Color(0xFF444444),
            ),
          ),
        ],
      ),
    );
  }
}

/// 작은 글자 태그 (다음 일정, 끝남 등)
class TextTag extends StatelessWidget {
  const TextTag({
    super.key,
    required this.text,
    this.filled = false,
    this.color = AppColors.inkStrong,
  });

  final String text;
  final bool filled;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: filled ? color : Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: filled ? null : Border.all(color: color, width: 2),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w800,
          color: filled ? Colors.white : color,
        ),
      ),
    );
  }
}

/// 아직 연결 안 된 기능 안내
void showTodoSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}
