import 'package:flutter/material.dart';

import '../data/sample_data.dart';
import '../screens/large_confirm_screen.dart';
import '../screens/save_confirm_screen.dart';
import '../state/app_state.dart';

/// 말하기 버튼을 눌렀을 때의 흐름.
///
/// TODO: 음성 인식(STT) → Firebase 함수(OpenAI) 일정 분석 결과로 바꾸세요.
/// 지금은 와이어프레임 예시 문장과 일정 2개로 확인 화면을 열어요.
Future<void> startVoiceFlow(BuildContext context, {bool replace = false}) {
  final large = AppStateScope.read(context).largeMode;
  final drafts = DemoData.drafts();
  const heard = DemoData.heardText;

  final route = MaterialPageRoute<void>(
    builder: (_) => large
        ? LargeConfirmScreen(heardText: heard, drafts: drafts)
        : SaveConfirmScreen(heardText: heard, drafts: drafts),
  );

  final navigator = Navigator.of(context);
  return replace ? navigator.pushReplacement(route) : navigator.push(route);
}
