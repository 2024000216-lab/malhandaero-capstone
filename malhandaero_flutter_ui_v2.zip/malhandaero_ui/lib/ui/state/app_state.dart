import 'package:flutter/widgets.dart';

import '../models/schedule.dart';

/// 앱 전체 상태: 일정 목록 + 보기 설정.
/// 외부 패키지 없이 ChangeNotifier + InheritedNotifier로 만들었어요.
class AppState extends ChangeNotifier {
  AppState({List<Schedule>? initial})
      : _schedules = [...?initial]..sort(_byTime);

  final List<Schedule> _schedules;
  bool _colorBlind = false;
  bool _largeMode = false;
  int _reminderMinutes = 60;

  List<Schedule> get schedules => List.unmodifiable(_schedules);
  bool get colorBlind => _colorBlind;
  bool get largeMode => _largeMode;
  int get reminderMinutes => _reminderMinutes;

  void setColorBlind(bool value) {
    if (_colorBlind == value) return;
    _colorBlind = value;
    notifyListeners();
  }

  void setLargeMode(bool value) {
    if (_largeMode == value) return;
    _largeMode = value;
    notifyListeners();
  }

  void setReminderMinutes(int minutes) {
    if (_reminderMinutes == minutes) return;
    _reminderMinutes = minutes;
    notifyListeners();
  }

  void addSchedules(Iterable<Schedule> items) {
    _schedules
      ..addAll(items)
      ..sort(_byTime);
    notifyListeners();
  }

  void updateSchedule(Schedule schedule) {
    final index = _schedules.indexWhere((s) => s.id == schedule.id);
    if (index < 0) return;
    _schedules[index] = schedule;
    _schedules.sort(_byTime);
    notifyListeners();
  }

  void removeSchedule(String id) {
    _schedules.removeWhere((s) => s.id == id);
    notifyListeners();
  }

  static int _byTime(Schedule a, Schedule b) => a.dateTime.compareTo(b.dateTime);
}

class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  /// build 안에서 사용: 상태가 바뀌면 화면이 다시 그려져요.
  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope != null, 'AppStateScope가 위젯 트리에 없어요');
    return scope!.notifier!;
  }

  /// 버튼 콜백 안에서 사용: 다시 그리기 구독 없이 읽기만 해요.
  static AppState read(BuildContext context) {
    final element =
        context.getElementForInheritedWidgetOfExactType<AppStateScope>();
    assert(element != null, 'AppStateScope가 위젯 트리에 없어요');
    return (element!.widget as AppStateScope).notifier!;
  }
}
