/// intl 패키지 없이 쓰는 한국어 날짜·시간 표기.
const _weekdays = ['월', '화', '수', '목', '금', '토', '일'];

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

String weekdayShort(DateTime d) => _weekdays[d.weekday - 1];

/// 10월 20일 화요일
String formatDate(DateTime d) =>
    '${d.month}월 ${d.day}일 ${weekdayShort(d)}요일';

/// 10월 20일 (화)
String formatDateShort(DateTime d) =>
    '${d.month}월 ${d.day}일 (${weekdayShort(d)})';

/// 오전 9시 / 낮 12시 / 오후 7시 30분
String formatTime(DateTime d) {
  final h = d.hour;
  final String base;
  if (h == 0) {
    base = '밤 12시';
  } else if (h < 12) {
    base = '오전 $h시';
  } else if (h == 12) {
    base = '낮 12시';
  } else {
    base = '오후 ${h - 12}시';
  }
  return d.minute == 0 ? base : '$base ${d.minute}분';
}

/// 오늘 · 10월 19일 월 / 내일 · 10월 20일 화 / 10월 23일 금
String dayHeader(DateTime day, DateTime now) {
  final d = dateOnly(day);
  final diff = d.difference(dateOnly(now)).inDays;
  final base = '${d.month}월 ${d.day}일 ${weekdayShort(d)}';
  if (diff == 0) return '오늘 · $base';
  if (diff == 1) return '내일 · $base';
  return base;
}

/// 2시간 뒤 / 30분 뒤 / 3일 뒤
String timeUntil(DateTime target, DateTime now) {
  final diff = target.difference(now);
  if (diff.isNegative) return '지남';
  if (diff.inHours >= 24) return '${diff.inDays}일 뒤';
  final h = diff.inHours;
  final m = diff.inMinutes % 60;
  if (h == 0) return '$m분 뒤';
  return m == 0 ? '$h시간 뒤' : '$h시간 $m분 뒤';
}
