# 말한대로 — 와이어프레임 5차 Flutter UI

와이어프레임 5차 화면을 Flutter 위젯으로 옮긴 코드입니다.
외부 패키지 없이 Flutter SDK만 씁니다. (`flutter_localizations`는 SDK에 포함)

## 들어 있는 것

```
lib/
├── main_ui_demo.dart          # 데모 실행용 진입점 (기존 main.dart는 안 건드림)
└── ui/
    ├── app.dart               # MalhandaeroApp: 테마·한국어·첫 화면
    ├── state/app_state.dart   # 일정 목록 + 색약/크게 보기/미리 알림 설정
    ├── models/schedule.dart
    ├── data/sample_data.dart  # 예시 데이터 (실행한 날 기준 오늘·내일·금요일)
    ├── theme/                 # 색상표, 테마
    ├── utils/                 # 한국어 날짜·시간 표기, 현재 시각(DateTime.now)
    ├── widgets/               # 큰 버튼, 켜짐/꺼짐, 점선 테두리
    ├── flows/voice_flow.dart  # 말하기 버튼 → 확인 화면 흐름
    └── screens/
        ├── save_confirm_screen.dart    # 01 이렇게 저장할까요?
        ├── edit_time_sheet.dart        # 02 시간 바꾸기 시트
        ├── menu_screen.dart            # 03 메뉴
        ├── settings_screen.dart        # 04 설정 (색약 모드)
        ├── schedule_list_screen.dart   # 05 일정 관리 (색약 모드 대응)
        ├── large_home_screen.dart      # 06 크게 보기 홈
        └── large_confirm_screen.dart   # 07 크게 보기 확인
docs/wireframe/v5/             # HTML 와이어프레임 (참고용)
```

## 화면 흐름

> 보고서 모드는 메뉴에서 제거했습니다.


- 첫 화면: 크게 보기 꺼짐 → 메뉴 / 켜짐 → 크게 보기 홈
- 말하기 버튼 → (보통) 01 확인 화면 / (크게 보기) 07 하나씩 확인
- 01에서 [고치기] → 날짜: 달력, 시간: 02 시트, 장소·할 일: 입력창
- 저장 → 일정 관리 화면
- 색약 모드를 켜면 일정 관리·버튼 색이 바뀌고, 끝난 일정은 점선 + "끝남"으로 보여요

## 아직 연결 안 된 부분 (TODO)

| 파일 | 할 일 |
|---|---|
| `flows/voice_flow.dart` | 예시 데이터 → 음성 인식 + Firebase(OpenAI) 분석 결과 |
| `screens/edit_time_sheet.dart` | "말로 하기" → 음성 인식 (지금은 시간 선택 창) |
| `large_home_screen.dart`, `large_confirm_screen.dart` | "소리로 읽어주기" → TTS |
| `app.dart` | 예시 일정 → Firebase에 저장된 일정 |
